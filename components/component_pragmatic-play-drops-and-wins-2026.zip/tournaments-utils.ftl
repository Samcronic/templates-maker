<#macro my value>
    <div style="margin-top:${value}px;margin-bottom:${value}px">
        <#nested>
    </div>
</#macro>


<#macro layout>
    <div style="font-family:inherit; max-width:960px; margin:auto; background: inherit;color: inherit;">
        <#nested>
    </div>
</#macro>

<#macro content title>
    <pre style="font-size:14px; font-family: sans-serif; font-weight: 400; color: #BBBCC3; line-height: 16px; white-space: pre-line;  margin:0px auto;">
        <div style="margin-bottom:10px; text-decoration: none; font-weight: 700; font-size: 12px">${title}</div>
        <#nested>
    </pre>
</#macro>







