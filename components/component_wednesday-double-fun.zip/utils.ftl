<#macro my value>
    <div style="margin-top:${value}px;margin-bottom:${value}px">
        <#nested>
    </div>
</#macro>


<#macro layout>
    <div style="font-family:inherit;max-width:960px;margin:auto;background:inherit;color:inherit;padding:20px;padding-top:0px">
        <#nested>
    </div>
</#macro>

<#macro headers1 values...>
    <#list values as head1 >
        <p style="font-size:24px;font-weight:bold;text-align:center; color: #ffffff;">
            ${head1}
        </p>
    </#list>
</#macro>

<#macro headers2 values...>
    <#list values as head2>
        <p style="font-size:18px;font-weight:bold;text-align:center; padding-bottom: 10px; color: #ffffff;">
			${head2}
		</p>
    </#list>
</#macro>

<#macro title values...>
    <#list values as v>
        <p style="padding-bottom: 5px; padding-top: 5px;">
            ${v}
        </p>
    </#list>
</#macro>

<#macro cta label link="/account/financials/deposit">
    <div style="display:flex;justify-content:center">
        <a href="${link}" target="_blank"
           style="align-self:center; font-size:14px; padding:16px 24px 16px 24px; text-align:center; text-transform:uppercase; text-decoration:none; display:inline-block; cursor:pointer; margin-top:10px;font-family:sans-serif; border-radius: 10px; background: #FF204F; color: #ffffff; font-weight: 700;">
            <strong>${label}</strong>
        </a>
    </div>
</#macro>


<#macro steps values...>
    <div style="display: flex; flex-direction: column; align-items: flex-start;">
        <#list values as v>
            <p style="margin:5px 0px;display:flex;flex-direction:row;align-items:center;align-content:center;">
                <span style="display:inline-block;line-height:100%;border-radius:50%;width:30px;height:30px;text-align:center;font-size:20px;font-weight:bold;padding:5px;flex-basis:30px;flex-grow:0;flex-shrink:0;margin-right:10px;background: #FF204F; color: #ffffff;">${v?index + 1}</span>
                <strong style=" font-family: inherit;float: left;width: calc(100% - 40px);margin-left: 10px;">${v}</strong>
            </p>
        </#list>
    </div>
</#macro>

<#macro content title>
    <pre style="font-size:12px;font-family:sans-serif;line-height:16px;white-space:pre-line;margin:0px auto;">
        <div style="margin-bottom:10px;font-weight:bold;text-decoration:underline">${title}</div>
        <#nested>
    </pre>
</#macro>


